const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const User = require('../models/User');

// Configuración de multer para almacenar archivos en /cvs
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, '..', 'cvs');
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath);
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const ext = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext).replace(/\s/g, '_');
    cb(null, `${timestamp}-${base}${ext}`);
  }
});
const upload = multer({ 
    storage,
    fileFilter: (req, file, cb) => {
      const isPDF = file.mimetype === 'application/pdf';
      if (isPDF) {
        cb(null, true);
      } else {
        cb(new Error('Solo se permiten archivos PDF'));
      }
    }
  });

// 📁 Ruta para subir el archivo del CV
router.post('/upload', (req, res) => {
    upload.single('cv')(req, res, (err) => {
      if (err instanceof multer.MulterError) {
        return res.status(500).json({ error: 'Error al subir el archivo' });
      } else if (err) {
        return res.status(400).json({ error: err.message });
      }
  
      if (!req.file) {
        return res.status(400).json({ error: 'No se subió ningún archivo' });
      }
  
      res.json({ filename: req.file.filename });
    });
  });
  

// 🧑 Ruta para registrar el usuario (con referencia a la vacante)
router.post('/create', async (req, res) => {
  try {
    const { nombre, edad, cv, vacante } = req.body;

    const nuevoUsuario = new User({
      nombre,
      edad,
      cv,
      vacante
    });

    await nuevoUsuario.save();
    res.json({ message: "Usuario creado con éxito", user: nuevoUsuario });
  } catch (err) {
    console.error('❌ Error al crear usuario:', err);
    res.status(500).json({ error: 'Error al crear usuario' });
  }
});

module.exports = router;
